package com.blrx.tvmov

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("tvmov_local", Context.MODE_PRIVATE)

    fun getFavorites(): List<MediaItem> = readList(KEY_FAVORITES)
    fun getWatchLater(): List<MediaItem> = readList(KEY_WATCH_LATER)
    fun getHistory(): List<MediaItem> = readList(KEY_HISTORY)

    fun toggleFavorite(item: MediaItem): Boolean = toggle(KEY_FAVORITES, item)
    fun toggleWatchLater(item: MediaItem): Boolean = toggle(KEY_WATCH_LATER, item)

    fun addHistory(item: MediaItem) {
        val current = readList(KEY_HISTORY).filterNot { it.key == item.key }.toMutableList()
        current.add(0, item)
        writeList(KEY_HISTORY, current)
    }

    fun clearHistory() = prefs.edit().remove(KEY_HISTORY).apply()
    fun clearFavorites() = prefs.edit().remove(KEY_FAVORITES).apply()
    fun clearWatchLater() = prefs.edit().remove(KEY_WATCH_LATER).apply()

    fun replaceFavorites(items: List<MediaItem>) = writeList(KEY_FAVORITES, items)
    fun replaceWatchLater(items: List<MediaItem>) = writeList(KEY_WATCH_LATER, items)
    fun replaceHistory(items: List<MediaItem>) = writeList(KEY_HISTORY, items)

    private fun toggle(key: String, item: MediaItem): Boolean {
        val current = readList(key).toMutableList()
        val exists = current.removeAll { it.key == item.key }
        if (!exists) current.add(0, item)
        writeList(key, current)
        return !exists
    }

    private fun readList(key: String): List<MediaItem> {
        val arr = runCatching { JSONArray(prefs.getString(key, "[]")) }.getOrNull() ?: JSONArray()
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    MediaItem(
                        id = o.optInt("id"),
                        mediaType = o.optString("mediaType"),
                        title = o.optString("title"),
                        poster = o.optString("poster").ifBlank { null },
                        year = o.optString("year"),
                        rating = if (o.has("rating")) o.optDouble("rating") else null,
                        overview = o.optString("overview"),
                        seasons = if (o.has("seasons")) o.optInt("seasons") else null,
                        sourceCategory = o.optString("sourceCategory").ifBlank { null }
                    )
                )
            }
        }
    }

    private fun writeList(key: String, items: List<MediaItem>) {
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(JSONObject().apply {
                put("id", item.id)
                put("mediaType", item.mediaType)
                put("title", item.title)
                put("poster", item.poster)
                put("year", item.year)
                if (item.rating != null) put("rating", item.rating)
                put("overview", item.overview)
                if (item.seasons != null) put("seasons", item.seasons)
                put("sourceCategory", item.sourceCategory)
            })
        }
        prefs.edit().putString(key, arr.toString()).apply()
    }

    companion object {
        private const val KEY_FAVORITES = "favorites"
        private const val KEY_WATCH_LATER = "watch_later"
        private const val KEY_HISTORY = "history"
    }
}
