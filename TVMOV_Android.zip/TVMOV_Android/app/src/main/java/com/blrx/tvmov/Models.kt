package com.blrx.tvmov

data class MediaItem(
    val id: Int,
    val mediaType: String,
    val title: String,
    val poster: String? = null,
    val year: String = "",
    val rating: Double? = null,
    val overview: String = "",
    val seasons: Int? = null,
    val sourceCategory: String? = null
) {
    val key: String get() = "$mediaType|$id"
    val isMovie: Boolean get() = mediaType == "movie"
    val isTv: Boolean get() = mediaType == "tv"
}

data class CastMember(
    val id: Int? = null,
    val name: String,
    val character: String = "",
    val photo: String? = null
)

data class DetailExtras(
    val cast: List<CastMember> = emptyList(),
    val similar: List<MediaItem> = emptyList()
)

data class SeasonInfo(val season: Int, val episodes: List<Int>)

enum class HomeSection(val label: String, val path: String) {
    Movies("أفلام", "movies"),
    Series("مسلسلات", "tv"),
    New("جديدنا", "new"),
    Trending("الترند", "trending"),
    TopRated("الأعلى تقييمًا", "top-rated"),
    Anime("أنمي وكرتون", "anime")
}

data class CatalogState(
    val sections: Map<HomeSection, List<MediaItem>> = emptyMap(),
    val loading: Boolean = false,
    val error: String? = null
)

data class PlayerSource(
    val label: String,
    val url: String,
    val direct: Boolean = false
)
