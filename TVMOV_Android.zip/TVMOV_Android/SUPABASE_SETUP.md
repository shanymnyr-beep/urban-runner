# TV MOV — Supabase connection

The Android project is connected to the TV MOV Supabase project using the project's **publishable** key. No secret/service-role key is included in the APK.

## Supabase project

- Project ref: `zosqvajletgvzqvxgzgu`
- Project URL: `https://zosqvajletgvzqvxgzgu.supabase.co`
- Mobile redirect URI: `tvmov://auth/callback`

## One dashboard setting required

In Supabase Dashboard → Authentication → URL Configuration → Additional Redirect URLs, add:

`tvmov://auth/callback`

This is required for signup email confirmation and password-recovery links to return to the Android app.

## Database created by the integration

- `public.profiles` — username, avatar URL, cover URL.
- `public.user_library` — favorites, watch-later, and history.
- RLS is enabled on both tables; authenticated users can only access their own rows.
- A profile is created automatically after a Supabase Auth user is created.
- Storage bucket `profile-media` is used for profile and cover images.

## Authentication

- Email + password sign up.
- Email + password sign in.
- Forgot-password email recovery.
- Password update after a recovery link.
- Login is optional; the catalog remains usable without an account.

## Local/offline behavior

Favorites, watch-later, and history continue to work locally without an account. After login, local lists are merged with the account lists and synchronized to Supabase.
